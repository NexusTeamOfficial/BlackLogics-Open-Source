# Material 3 (Material Symbols) Icon Pack

Matched from the old Material Design 1 icon pack (2014).

## Styles Included

| Folder     | Style                          | Description                          |
|------------|--------------------------------|--------------------------------------|
| outlined/  | Material Symbols Outlined      | Default outline style                |
| filled/    | Material Symbols Filled        | FILL=1 (solid) version               |
| rounded/   | Material Symbols Rounded       | Soft rounded corners                 |
| sharp/     | Material Symbols Sharp         | Sharp corners, modern look           |

~717–719 icons per style (most of the original 757 matched).

## Naming

Files keep the original names from the old pack (without `ic_` prefix and `_24dp` suffix).

Some icons were renamed in Material Symbols — closest equivalent used:

- airplanemode_off → airplanemode_inactive
- airplanemode_on → airplanemode_active
- *_outline → base icon or *_border
- play_circle_fill / play_circle_outline → play_circle
- radio_button_off → radio_button_unchecked
- etc.

## Technical Details

- Format: SVG 24px
- ViewBox: usually `0 -960 960 960`
- Single path, black fill (easy to recolor with CSS `fill` or Android tint)
- Source: Official Google Material Symbols  
  https://github.com/google/material-design-icons  
  https://fonts.google.com/icons

## Usage Tips

- **Web**: Use as-is. Set `fill="currentColor"` or CSS fill.
- **Android**: Convert SVG → Vector Drawable, or use Material Symbols font + variable axes.
- **Best for Material 3**: Prefer **Rounded** or **Outlined** depending on your design system.

A few very rare/obscure icons from 2014 could not be perfectly matched.
